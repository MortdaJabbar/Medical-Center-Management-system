

 $(document).on('click', '.edit-btn', function () {
    id= $(this).data('id');
    editMedication(id);
});

 
 
 function editMedication(id) {
        $.get(`https://localhost:7119/api/Medications/${id}`, function (med) {
            $('#editMedicationId').val(med.medicationID);
            $('#editMedName').val(med.name);
            $('#editMedDescription').val(med.description);
            $('#editMedStrength').val(med.strength);
            $('#editMedDosageForm').val(med.dosageForm);
            $('#editMedicationModal').modal('show');
        });

        
    }

$('#editMedicationForm').submit(function (e) {
    e.preventDefault();

    const updatedMed = {
         
        name: $('#editMedName').val(),
        description: $('#editMedDescription').val(),
        strength: $('#editMedStrength').val(),
        dosageForm: $('#editMedDosageForm').val()
    };

    
    $.ajax({
        url: `https://localhost:7119/api/Medications/update/${id}`,
        method: 'PUT',
        contentType: 'application/json',
        data: JSON.stringify(updatedMed),
        success: function () {
            $('#editMedicationModal').modal('hide');
            loadMedications();
        },
        error: function () {
            alert('Update failed.');
        }
    });
});