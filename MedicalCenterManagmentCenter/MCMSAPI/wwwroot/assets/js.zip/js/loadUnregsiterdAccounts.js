function loadAvailableEntities() {
  const roleId = $('#role').val();
  let url = "";

  switch (parseInt(roleId)) {
    case 2: url = "https://localhost:7119/api/Users/unregistered-doctors"; break;
    case 3: url = "https://localhost:7119/api/Users/unregistered-patients"; break;
    case 4: url = "https://localhost:7119/api/Users/unregistered-pharmacists"; break;
    case 5: url = "https://localhost:7119/api/Users/nregistered-staff"; break;
    default: return;
  }

  $.get(url, function (data) {
    const select = $('#personId');
    select.empty();
    select.append(`<option disabled selected>Choose from list</option>`);
    data.forEach(item => {
      const id = item.doctorId || item.patientId || item.pharmacistId || item.staffId;
      select.append(`<option value="${id}">${item.fullName}</option>`);
    });
  });
}
