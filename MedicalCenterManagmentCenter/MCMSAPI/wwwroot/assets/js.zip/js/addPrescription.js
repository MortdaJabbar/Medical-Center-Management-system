
$(document).ready(function () {
    $('#addPrescriptionForm').submit(function (e) {
        e.preventDefault(); // يمنع إعادة تحميل الصفحة

        const prescription = {
            patientId: $('#addPrescriptionPatientId').val(),
            doctorId: $('#addPrescriptionDoctorId').val(),
            medicationId: $('#addMedicationSelect').val(),
            prescriptionDate: $('#addPrescriptionDate').val(),
            refills: $('#addPrescriptionRefills').val() || null,
            instructions: $('#addPrescriptionInstructions').val()
        };

        $.ajax({
            url: 'https://localhost:7119/api/Prescriptions/add',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(prescription),
            success: function () {
                $('#addPrescriptionModal').modal('hide');
                $('#addPrescriptionForm')[0].reset();
                loadPrescriptions(); // إعادة تحميل الجدول
                alert('✅ Prescription added successfully.');
            },
            error: function () {
                alert('❌ Failed to add prescription.');
            }
        });
    });
});
