$(document).ready(function () {

     loadMedicationsDropdown();
    $('#addInventoryForm').submit(function (e) {
        e.preventDefault();

        const newInventory = {
            medicationID: $('#addMedicationSelect').val(),
            quantity: $('#addQuantity').val(),
            unitOfMeasure: $('#addUnit').val(),
            supplier: $('#addSupplier').val(),
            expiryDate: $('#addExpiry').val(),
            recivedDate: $('#addReceived').val()
        };

        $.ajax({
            url: "https://localhost:7119/api/Inventory/add",
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify(newInventory),
            success: function () {
                $('#addInventoryModal').modal('hide');
                $('#addInventoryForm')[0].reset();
                loadInventory();
            },
            error: function () {
                alert("Failed to add inventory.");
            }
        });
    });
});
