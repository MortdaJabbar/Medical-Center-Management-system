
function confirmDeletePrescription(button) {
    const id = $(button).data('id');
    $('#deletePrescriptionId').val(id);
    $('#deletePrescriptionModal').modal('show');
}
let deleteid =0;
$(document).ready(function () {
    $('#confirmDeletePrescriptionBtn').click(function () {
        deleteid = $('#deletePrescriptionId').val();

        $.ajax({
            url: `https://localhost:7119/api/Prescriptions/${deleteid}`,
            method: 'DELETE',
            success: function () {
                $('#deletePrescriptionModal').modal('hide');
                loadPrescriptions();
                alert('✅ Prescription deleted successfully.');
            },
            error: function () {
                alert('❌ Failed to delete prescription.');
            }
        });
    });
});

