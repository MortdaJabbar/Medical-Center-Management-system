$('#addTestForm').submit(function (e) {
    e.preventDefault();

    const patientId = $('#addPatientId').val();
    const doctorId = $('#addDoctorId').val();
    const testTypeId = $('#addTestTypeId').val();
    const cost = $('#addCost').val();
    const status = $('#addStatus').val();
    const notes = $('#addNotes').val();
    const createdAt = new Date().toISOString().split('T')[0]; // yyyy-MM-dd

    const fileInput = $('#addTestResult')[0];
    let testResult = null;

    if (fileInput.files.length > 0) {
        const fileName = fileInput.files[0].name;
        testResult = `C:\\Files\\${fileName}`;
    }

    const newTest = {
        patientID: patientId,
        doctorID: doctorId,
        testTypeID: testTypeId,
        cost: parseFloat(cost),
        status: parseInt(status),
        notes: notes,
        testResult: testResult,
        createdAt: createdAt
    };

    $.ajax({
        url: 'https://localhost:7119/api/Tests/add',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(newTest),
        success: function () {
            const modal = bootstrap.Modal.getInstance(document.getElementById('addTestModal'));
            modal.hide();
            $('#addTestForm')[0].reset();
            loadTests();
        },
        error: function () {
            alert('Failed to add new test.');
        }
    });
});
