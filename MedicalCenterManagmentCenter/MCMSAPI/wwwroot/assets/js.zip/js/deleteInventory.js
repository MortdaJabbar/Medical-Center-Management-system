$(document).ready(function () {
    $(document).on('click', '.delete-inv-btn', function () {
        const id = $(this).data('id');
        $('#deleteInventoryId').val(id);
        $('#deleteInventoryModal').modal('show');
    });

    $('#confirmDeleteInventoryBtn').click(function () {
        const id = $('#deleteInventoryId').val();

        $.ajax({
            url: `https://localhost:7119/api/Inventory/${id}`,
            method: 'DELETE',
            success: function () {
                $('#deleteInventoryModal').modal('hide');
                loadInventory();
            },
            error: function () {
                alert('Failed to delete inventory.');
            }
        });
    });
});
