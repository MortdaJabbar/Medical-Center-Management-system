function loadMedicationsDropdown() {
    $.get("https://localhost:7119/api/Medications/all", function (meds) {
        const addSelect = $("#addMedicationSelect");
        addSelect.empty();

        meds.forEach(med => {
            const option = `<option value="${med.medicationID}">${med.name}</option>`;
            addSelect.append(option);
             
        });
    });
}

