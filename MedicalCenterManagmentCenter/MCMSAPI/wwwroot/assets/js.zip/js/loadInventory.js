function loadInventory() {
    $.get("https://localhost:7119/api/Inventory/AllDetails", function (data) {
        const tbody = $("#inventory-body");
        tbody.empty();

        data.forEach(inv => {
            const row = `
                <tr>
                    <td class="p-3">${inv.medicationName ?? inv.medicationID}</td>
                    <td class="p-3">${inv.quantity}</td>
                    <td class="p-3">${inv.unitOfMeasure}</td>
                    <td class="p-3">${inv.supplier}</td>
                    <td class="p-3">${inv.expiryDate}</td>
                    <td class="p-3">${inv.recivedDate}</td>
                    <td class="p-3 text-end">
                        <button class="btn btn-sm btn-primary me-2 edit-inv-btn" data-id="${inv.inventoryID}">Edit</button>
                        <button class="btn btn-sm btn-danger delete-inv-btn" data-id="${inv.inventoryID}">Delete</button>
                    </td>
                </tr>`;
            tbody.append(row);
        });
    });
}

$(document).ready(function () {
    loadInventory();
});
