$('#addMedicationForm').submit(function (e) {
    e.preventDefault();

    const newMedication = {
        name: $('#medName').val(),
        description: $('#medDescription').val(),
        strength: $('#medStrength').val(),
        dosageForm: $('#medDosageForm').val()
    };

    $.ajax({
        url: 'https://localhost:7119/api/Medications/add',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(newMedication),
        success: function () {
            $('#addMedicationModal').modal('hide');
            $('#addMedicationForm')[0].reset();
            loadMedications(); // تحديث الجدول
        },
        error: function () {
            alert('Failed to add medication.');
        }
    });
});
