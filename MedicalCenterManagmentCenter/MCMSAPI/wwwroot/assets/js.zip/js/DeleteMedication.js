// فتح مودال الحذف عند الضغط على زر الحذف
$(document).on('click', '.delete-btn', function () {
    const id = $(this).data('id'); // قراءته من الزر
    $('#deleteMedicationId').val(id); // خزن المعرف في حقل مخفي
    $('#deleteMedicationModal').modal('show'); // فتح المودال
});

// تنفيذ الحذف عند التأكيد
$('#confirmDeleteBtn').click(function () {
    const id = $('#deleteMedicationId').val();

    $.ajax({
        url: `https://localhost:7119/api/Medications/${id}`, // تأكد من المسار الصحيح
        method: 'DELETE',
        success: function () {
            $('#deleteMedicationModal').modal('hide'); // إغلاق المودال
            loadMedications(); // إعادة تحميل الجدول
        },
        error: function () {
            alert('Failed to delete medication.');
        }
    });
});
