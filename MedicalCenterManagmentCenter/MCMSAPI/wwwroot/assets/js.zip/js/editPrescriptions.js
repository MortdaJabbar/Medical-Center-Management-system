
function editPrescription(button) {
    const id = $(button).data('id');

    // ابحث عن البيانات داخل الصف (من جدول موجود سابقًا)
    const row = $(button).closest('tr');

    const patientName = row.find('td:eq(0)').text().trim();
    const doctorName = row.find('td:eq(1)').text().trim();
    const medicationId = row.find('td:eq(2)').text().trim();
    const prescriptionDate = row.find('td:eq(3)').text().trim();
    const refills = row.find('td:eq(4)').text().trim();
    const instructions = row.find('td:eq(5)').text().trim();

    // تعبئة المودال
    $('#editPrescriptionId').val(id);
    $('#editPrescriptionPatientId').empty().append(`<option selected>${patientName}</option>`);
    $('#editPrescriptionDoctorId').empty().append(`<option selected>${doctorName}</option>`);

    // تحميل قائمة الأدوية
    $.get("https://localhost:7119/api/Medications/all", function (meds) {
        const medSelect = $("#editMedicationSelect");
        medSelect.empty().append('<option disabled>Select Medication</option>');
        meds.forEach(med => {
            const selected = med.medicationID == medicationId ? 'selected' : '';
            medSelect.append(`<option value="${med.medicationID}" ${selected}>${med.name}</option>`);
        });
    });

    $('#editPrescriptionDate').val(new Date(prescriptionDate).toISOString().split('T')[0]);
    $('#editPrescriptionRefills').val(refills !== "-" ? refills : "");
    $('#editPrescriptionInstructions').val(instructions);

    $('#editPrescriptionModal').modal('show');
}
let id =0;
// submit form
$(document).ready(function () {
    $('#editPrescriptionForm').submit(function (e) {
        e.preventDefault();

         id = $('#editPrescriptionId').val();

        const prescription = {
            
            medicationId: $('#editMedicationSelect').val(),
            prescriptionDate: $('#editPrescriptionDate').val(),
            refills: $('#editPrescriptionRefills').val() || null,
            instructions: $('#editPrescriptionInstructions').val()
        };

        $.ajax({
            url: `https://localhost:7119/api/Prescriptions/update/${id}`,
            method: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify(prescription),
            success: function () {
                $('#editPrescriptionModal').modal('hide');
                loadPrescriptions();
                alert('✅ Prescription updated successfully.');
            },
            error: function () {
                alert('❌ Failed to update prescription.');
            }
        });
    });
});
