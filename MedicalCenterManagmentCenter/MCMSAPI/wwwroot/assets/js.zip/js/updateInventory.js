let myid = 0;
$(document).ready(function () {
    $(document).on('click', '.edit-inv-btn', function () {
        const id = $(this).data('id');
        myid=id;

        $.get(`https://localhost:7119/api/Inventory/${id}`, function (inv) {
            $('#editInventoryId').val(inv.inventoryID);
            $('#editMedicationSelect').val(inv.medicationID);
            $('#editQuantity').val(inv.quantity);
            $('#editUnit').val(inv.unitOfMeasure);
            $('#editSupplier').val(inv.supplier);
            $('#editExpiry').val(inv.expiryDate);
            $('#editReceived').val(inv.recivedDate);
            $('#editInventoryModal').modal('show');
        });
    });

    $('#editInventoryForm').submit(function (e) {
        e.preventDefault();

        const updatedInventory = {
            medicationID: $('#editMedicationSelect').val(),
            quantity: $('#editQuantity').val(),
            unitOfMeasure: $('#editUnit').val(),
            supplier: $('#editSupplier').val(),
            expiryDate: $('#editExpiry').val(),
            recivedDate: $('#editReceived').val()
        };

        $.ajax({
            url: `https://localhost:7119/api/Inventory/update/${myid}`,
            method: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify(updatedInventory),
            success: function () {
                $('#editInventoryModal').modal('hide');
                loadInventory();
            },
            error: function () {
                alert('Failed to update inventory.');
            }
        });
    });
});
